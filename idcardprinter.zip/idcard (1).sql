-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2023 at 06:58 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idcard`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_no` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `program_name` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `principle_name` varchar(255) NOT NULL,
  `student_photo` varchar(255) NOT NULL,
  `entry_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `id_no`, `session`, `roll_no`, `blood_group`, `student_name`, `program_name`, `father_name`, `dob`, `address`, `mobile`, `email`, `principle_name`, `student_photo`, `entry_by`) VALUES
(1, '002', '2023-2026', '002', 'O-', 'ASHISH ANAND', 'BBA', 'MR. KISLOY DUTTA THAKUR', '2001-09-06', 'L . N . Mishra Colony, Itki Road,834005, Ranchi', '7903755407', 'ashishrishu2018@gmail.com', 'B.P. Verma', '1701153271WhatsApp Image 2023-11-28 at 12.00.51_208a74ef.jpg', 'kritika'),
(3, '0003', '2023-2026', '0003', 'O+', 'ANKIT SINGH', 'BBA', 'KULDEEP SINGH', '2004-05-29', 'Vill- Tengria, Konaslata, PS- Palkot', '6202267906', 'ankitsinghstudentid@gmail.com', 'B.P. Verma', '1701153789WhatsApp Image 2023-11-28 at 12.08.58_0e7a8e8b.jpg', 'kritika'),
(4, '0004', '2023-2026', '0004', 'O+', 'SIDDHANT KUMAR', 'BBA', 'DEEPAK KUMAR', '2004-06-05', 'Chutia, Ranchi, 834010', '9135833730', 'siddhantkumarofficial@gmail.com', 'B.P. Verma', '1701154138WhatsApp Image 2023-11-28 at 12.18.24_2c84e6c6.jpg', 'kritika'),
(5, '0009', '2023-2026', '0009', 'O+', 'JYOTI KUMARI', 'BBA', 'VIKRAM SINGH', '2005-03-02', 'Hinoo, New P.H.E.D Colony, Ranchi -2', '7667626897', 'jyoti098uu@gmail.com', 'B.P. Verma', '1701154770WhatsApp Image 2023-11-28 at 12.20.19_51aa631a.jpg', 'kritika'),
(6, '06', '2023-27', '06', 'B+', 'Ankit Kumar', 'B.A', 'Nandkishor Sahu', '2004-01-04', 'Hundru', '7254037524', '', 'B.P. Verma', '1701156243WhatsApp Image 2023-11-28 at 12.34.11 PM.jpeg', 'Sahil'),
(7, '155', '2023-2027', '155', 'O+', 'ALOK XALXO', 'B.A', 'AMRIT XALXO', '2004-12-06', 'VILL+P.O-Burha Khukhra', '9608856896', 'xalxoalok@gmail.com', 'B.P. Verma', '1701156334WhatsApp Image 2023-11-28 at 12.34.15 PM.jpeg', 'Saif'),
(8, '123', '2023-27', '123', 'O+', 'kshitiz kumar', 'BCA', 'B N Sharma', '2023-11-18', 'Harmu\r\nVidya Nagar', '+919006042011', 'kshitiz.ranchi@gmail.com', 'B.P. Verma', '1701195104p1.jpg', 'Saif'),
(9, 'MCA01', '2019-21', 'MCA01', 'O+', 'Kshitiz kumar', 'MCA', 'B N SHarma', '1998-03-10', 'Ranchi Jharkhand', '9006042011', 'kshitiz.ranchi@gmail.com', 'B.P. Verma', '1701247814p1.jpg', 'kritika');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
