<?php 
session_start();

include'db.php';

if(isset($_POST['login']))
{
	$username= $_POST['username'];
	$password= $_POST['password'];

				if($username=="kritika" AND $password=="pass")
				{
				    $_SESSION['login']="kritika";
					header("location:admin/update_students.php");
				}
				elseif($username=="Sahil" AND $password=="pass")
				{
				    $_SESSION['login']="Sahil";
					header("location:admin/update_students.php");
				}
				elseif($username=="Saif" AND $password=="pass")
				{
				    $_SESSION['login']="Saif";
					header("location:admin/update_students.php");
				}
				elseif($username=="Priyanshu" AND $password=="pass")
				{
				    $_SESSION['login']="Priyanshu";
					header("location:admin/update_students.php");
				}
				elseif($username=="admin" AND $password=="pass")
				{
				    $_SESSION['login']="admin";
					header("location:admin/update_students.php");
				}
				else
				{
					header("location:index.php");
				}
			// end admin
	

	

}



 ?>