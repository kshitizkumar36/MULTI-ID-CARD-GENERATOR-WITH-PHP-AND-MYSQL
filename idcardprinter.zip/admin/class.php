<?php



class connection
{
	protected $connect;
 
	public function __construct()
	{
		 include'../db.php';
		$this->connect= $connect;
	}
	// protected $connect=  mysqli_connect("localhost","root","","apnagao");
}


class details extends connection
{

		public function get_products($id)
	{
		$connect= $this->connect;
		if($id=="admin")
		{
				$query="SELECT * FROM `users` ";
				$run= mysqli_query($connect,$query);
				$count= mysqli_num_rows($run);
				if($count>0)
				  {
						while($data= mysqli_fetch_array($run))
						{
							$data2[]= $data;
						}
							return $data2;
				  }
		}
		$query="SELECT * FROM `users` WHERE `entry_by`='$id'";
		$run= mysqli_query($connect,$query);
		$count= mysqli_num_rows($run);
		if($count>0)
		  {
				while($data= mysqli_fetch_array($run))
				{
					$data2[]= $data;
				}
					return $data2;
		  }
	
	}




	public function get_products_byid($id)
	{
		$connect= $this->connect;
		$query="SELECT * FROM `users` WHERE `id`='$id'";
		$run= mysqli_query($connect,$query);
		$count= mysqli_num_rows($run);
		if($count>0)
		  {
				$data= mysqli_fetch_array($run);
				
					return $data;
		  }
	
	}








}

?>