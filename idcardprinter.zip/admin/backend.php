<?php 
session_start();
include'../db.php';


if(isset($_POST['new_students']))
{
	$ID_no= $_POST['ID_no'];
		if(empty($ID_no)){$_SESSION['failed']="ID_no Can't be empty!!"; header("location:update_students.php"); exit();}
	$session=$_POST['session'];
		if(empty($session)){$_SESSION['failed']=" session Can't be empty!!"; header("location:update_students.php"); exit();}
	$s_roll_no= $_POST['s_roll_no'];
		if(empty($s_roll_no)){$_SESSION['failed']="ROll No Can't be empty!!"; header("location:update_students.php"); exit();}
	$blood_group= $_POST['blood_group'];
		if(empty($blood_group)){$_SESSION['failed']="blood_group Can't be empty!!"; header("location:update_students.php"); exit();}
	$student_name= $_POST['student_name'];
		if(empty($student_name)){$_SESSION['failed']="student_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$program_name= $_POST['program_name'];
		if(empty($program_name)){$_SESSION['failed']="program_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$father_name= $_POST['father_name'];
		if(empty($father_name)){$_SESSION['failed']="father_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$dob = $_POST['dob'];
		if(empty($dob)){$_SESSION['failed']="dob Can't be empty!!"; header("location:update_students.php"); exit();}
	

	$address = $_POST['address'];
		if(empty($address)){$_SESSION['failed']="address Can't be empty!!"; header("location:update_students.php"); exit();}
	
	$mobile = $_POST['mobile'];
		if(empty($mobile)){$_SESSION['failed']="mobile Can't be empty!!"; header("location:update_students.php"); exit();}
	
	$principle_name = $_POST['principle_name'];
		if(empty($principle_name)){$_SESSION['failed']="principle_name Can't be empty!!"; header("location:update_students.php"); exit();}

		$email = $_POST['email'];
		if(empty($email)){$_SESSION['failed']="email Can't be empty!!"; header("location:update_students.php"); exit();}
	


	$student_photo= $_FILES['student_photo']['name'];
		if(empty($student_photo)){$_SESSION['failed']="Photo Can't be empty!!"; header("location:update_students.php"); exit();}
		$student_photo_file= time().$student_photo;
		
		$entry_by = $_POST['entry_by'];
		if(empty($entry_by)){$_SESSION['failed']="entry_by Can't be empty!!"; header("location:update_students.php"); exit();}
	



	$query="INSERT INTO `users`(`id_no`,`session`, `roll_no`, `blood_group`, `student_name`, `program_name`, `father_name`, `dob`, `address`, `mobile`,`email`, `principle_name`,`student_photo`,`entry_by`) VALUES ('$ID_no','$session','$s_roll_no','$blood_group','$student_name','$program_name','$father_name','$dob','$address','$mobile','$email','$principle_name','$student_photo_file','$entry_by')";

	$run= mysqli_query($connect,$query);
	if($run)
	{
		move_uploaded_file($_FILES['student_photo']['tmp_name'], "../student_photo/$student_photo_file");
		
		$_SESSION['success']="Student Added Successfully!!";
		header("location:update_students.php");
	}

}


if(isset($_POST['update_data']))
{
	$ID_no= $_POST['ID_no'];
		if(empty($ID_no)){$_SESSION['failed']="ID_no Can't be empty!!"; header("location:update_students.php"); exit();}
	$session=$_POST['session'];
		if(empty($session)){$_SESSION['failed']=" session Can't be empty!!"; header("location:update_students.php"); exit();}
	$s_roll_no= $_POST['s_roll_no'];
		if(empty($s_roll_no)){$_SESSION['failed']="ROll No Can't be empty!!"; header("location:update_students.php"); exit();}
	$blood_group= $_POST['blood_group'];
		if(empty($blood_group)){$_SESSION['failed']="blood_group Can't be empty!!"; header("location:update_students.php"); exit();}
	$student_name= $_POST['student_name'];
		if(empty($student_name)){$_SESSION['failed']="student_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$program_name= $_POST['program_name'];
		if(empty($program_name)){$_SESSION['failed']="program_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$father_name= $_POST['father_name'];
		if(empty($father_name)){$_SESSION['failed']="father_name Can't be empty!!"; header("location:update_students.php"); exit();}
	$dob = $_POST['dob'];
		if(empty($dob)){$_SESSION['failed']="dob Can't be empty!!"; header("location:update_students.php"); exit();}
	

	$address = $_POST['address'];
		if(empty($address)){$_SESSION['failed']="address Can't be empty!!"; header("location:update_students.php"); exit();}
	
	$mobile = $_POST['mobile'];
		if(empty($mobile)){$_SESSION['failed']="mobile Can't be empty!!"; header("location:update_students.php"); exit();}
	
	$principle_name = $_POST['principle_name'];
		if(empty($principle_name)){$_SESSION['failed']="principle_name Can't be empty!!"; header("location:update_students.php"); exit();}

		$email = $_POST['email'];
		if(empty($email)){$_SESSION['failed']="email Can't be empty!!"; header("location:update_students.php"); exit();}
	

	$table_id= $_POST['table_id'];
	$query="UPDATE `users` SET `id_no`='$ID_no',`session`='$session',`roll_no`='$s_roll_no',`blood_group`='$blood_group',`student_name`='$student_name',`program_name`='$program_name',`father_name`='$father_name',`dob`='$dob',`address`='$address',`mobile`='$mobile',`email`='$email',`principle_name`='$principle_name' WHERE `id`='$table_id'";
	$run= mysqli_query($connect,$query);
	if($run)
	{
		
		$_SESSION['success']="Student Updated Successfully!!";
		header("location:update_students.php");
	}
	else
	{
		$_SESSION['faild']="Student Failed to Update!!";
		header("location:update_students.php");
	}
}





if(isset($_GET['remove_product']))
{
	$id= $_GET['remove_product'];
	$query="DELETE FROM `users` WHERE `id`='$id'";
	$run= mysqli_query($connect,$query);
	if($run)
	{
		$_SESSION['success']="Product Deleted!!";
		header("location:update_students.php");
	}
}



?>