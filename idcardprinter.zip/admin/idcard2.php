<?php
$id= $_GET['id'];

?>



<?php
include'class.php';
$class_var= new details;

$mydata= $class_var->get_products_byid($id);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Doranda ID Card</title>
  </head>
  <body>
    


<section class="container">
  <div class="row">
    <div class="col-sm-1"></div>



        <div  style="border-style: solid;border-color: black;" class="col-sm-9">

          <div style="background-color: #ffd238;height: ; ">
            <div class="row">
              <div class="col-sm-2">
                <h1 class="p-2" style="font-size: 30px;"><b>/<</b> </h1>
              </div>

                    <div style="background-color: #0f54f4; height: 100px;border-radius: 0px 0px 0px 50px;" class="col-sm-10 ">
                      <h6 style="padding-left: 50px; padding-top: 20px; font-size: 40px;" class="text-white"><b>Full Stack Development</b></h6>
                    </div>

                    
            </div>

            <div class="text-center">
               <h6 style=" font-size: 25px;" class="text-dark"><b>IDENITY CARD</b></h6>
            </div>
          </div>



                                  <!-- ****************************** -->

                                          <div class="container-fluid">
                                            <div class="row">
                                              <div class="col-sm-1"></div>
                                              <div class="col-sm-2">
                                                <h4><b><?php echo $mydata['id_no']; ?></b></h4>
                                              </div>
                                              <!-- <div class="col-sm-2"></div> -->
                                              <div  class="col-sm-6 text-center">
                                                <h2 >Session: <?php echo $mydata['session']; ?></h2>
                                              </div>
                                            </div>
                                           <!--  <div class="text-center">
                                              <img style="height: 190px; width: 190px;" src="../student_photo/k.jpg">
                                            </div> -->
                                          </div>



                                          <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style="padding-top: 70px; padding-left: 120px;"><b>Roll No: <br><?php echo $mydata['roll_no']; ?></b></h4>
                                            </div>
                                            <div class="col-sm-4">
                                               <img style="height: 190px; width: 190px;" src="../student_photo/<?php echo $mydata['student_photo']; ?>">
                                               <h4 class="text-danger text-center pt-2"><b><?php echo $mydata['student_name']; ?></b></h4>
                                            </div>
                                            <div class="col-sm-4">
                                              <img style="padding-top: 30px;" src="../student_assets/blood.png"><br>
                                              <h1><b class="text-danger"><?php echo $mydata['blood_group']; ?></b></h1>
                                            </div>
                                          </div>



                                          <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style="padding-top: 70px; padding-left:50px;"><b>Programme</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style="padding-top: 70px; padding-left: 40px;"><b><?php echo $mydata['program_name']; ?></h4>
                                            </div>
                                          </div>




                                          <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style=" padding-left:50px;"><b>Father's Name</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['father_name']; ?></h4>
                                            </div>
                                          </div>



                                          <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style=" padding-left:50px;"><b>Date of Birth :</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['father_name']; ?></h4>
                                            </div>
                                          </div>


                                        <!--   <div class="row">
                                            <div class="col-sm-3">
                                              <h4 style=" padding-left:50px;"><b>Address :</h4>
                                            </div>
                                            <div class="col-sm-9">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['address']; ?></h4>
                                            </div>
                                          </div>

 -->

                                           <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style=" padding-left:50px;"><b>Address :</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['address']; ?></h4>
                                            </div>
                                          </div>




                                              <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style=" padding-left:50px;"><b>Mobile :</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['mobile']; ?></h4>
                                            </div>
                                          </div>


                                             <div class="row">
                                            <div class="col-sm-4">
                                              <h4 style=" padding-left:50px;"><b>Email :</h4>
                                            </div>
                                            <div class="col-sm-8">
                                               <h4 style=" padding-left: 40px;"><b><?php echo $mydata['email']; ?></h4>
                                            </div>
                                          </div>




                                  <!-- ******************************** -->
                                  <div class="row">
                                    <div class="col-sm-9"></div>
                                    <div class="col-sm-3">
                                      <b><?php echo $mydata['principle_name']; ?></b>
                                    </div>
                                  </div>


                                  <div style="background-color: #0f54f4; height: 3px;"></div>
                                  <div style="background-color: #0f54f4; height: 50px; margin-top: 10px;">
                                    <div class="row">
                                      <div class="col-sm-9"></div>
                                      <div class="col-sm-3">
                                        <b style="font-size: 20px;" class="text-white ">Principle</b>
                                      </div>
                                    </div>
                                  </div>
                                   
        </div>



        <div class="col-sm-4"></div>
  </div>
</section>





  











    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>