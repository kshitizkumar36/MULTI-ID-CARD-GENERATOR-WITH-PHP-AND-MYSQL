
<?php
$id= $_GET['id'];

?>



<?php
include'class.php';
$class_var= new details;

$mydata= $class_var->get_products_byid($id);

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
      integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="idcard/style.css" />
    <title>Doranda ID Card</title>
  </head>
  <body>
    <section class="container main">
      <div class="row">

        <div style="border-style: solid; border-color: black" class="col-sm-9">
          <div style="background-color: #ffd238" class="tt">
            <div class="row">
              <div class="col-sm-2 logo">
                <img width="110" src="idcard/logo (1).png" />
              </div>

              <div
                style="
                  background-color: #0f54f4;
                  height: 100px;
                  border-radius: 0px 0px 0px 50px;
                "
                class="col-sm-10"
              >
                <h6
                  style="padding-left: 50px; padding-top: 20px; font-size: 40px"
                  class="text-white"
                >
                  <b>DORANDA COLLEGE RANCHI</b>
                </h6>
              </div>
            </div>

            <div class="text-center">
              <h2 class="id-header"><b>IDENITTY CARD</b></h2>
            </div>
          </div>

          <!-- ****************************** -->

          <div class="container-fluid">
            <div class="row">
             
              <div class="Session-main">
                <h4><?php echo $mydata['id_no']; ?></h4>
                <h2 >Session: <?php echo $mydata['session']; ?></h2>
              </div>
            </div>
          </div>

          <div class="row user-main-box">
            <div class="col-sm-2 roll-box">
              <h4>
                <b>Roll No. <br /><?php echo $mydata['roll_no']; ?></b>
              </h4>
            </div>
            <div>
              <img class="user-img" src="../student_photo/<?php echo $mydata['student_photo']; ?>" />
              <h4 class="text-danger text-center pt-2"><b><?php echo $mydata['student_name']; ?></b></h4>
            </div>
            <div class="col-sm-1 blood-box">
              <img style="padding-top: 30px; margin-top: -60px;" src="idcard/blood.png" />
              <b style="font-size: 24px; color: red; margin-top: -60px;margin-left: 60px;"><?php echo $mydata['blood_group']; ?></b>
            </div>
          </div>
         

          <table>
            <tr>
              <th class="t-head">Programme</th>
              <th><?php echo $mydata['program_name']; ?></th>
            </tr>
            <tr>
              <th class="t-head">Father's Name</th>
              <th><?php echo $mydata['father_name']; ?></th>
            </tr>
            <tr>
              <th class="t-head">Date of Birth :</th>
              <th><?php echo $mydata['dob']; ?></th>
            </tr>
            <tr>
              <th class="t-head">Address :</th>
              <th><?php echo $mydata['address']; ?></th>
            </tr>
            <tr>
              <th class="t-head">Mobile No :</th>
              <th><?php echo $mydata['mobile']; ?></th>
            </tr>
          </table>

          <h5 class="b-p">B.P. Verma</h5>
          <!-- ******************************** -->

          <div style="background-color: #0f54f4; height: 3px"></div>
          <div
            style="background-color: #0f54f4; height: 50px; margin-top: 10px"
          >
            <div class="row">
              <div class="col-sm-9"></div>
              <div class="col-sm-3">
                <b style="font-size: 20px" class="text-white">Principle</b>
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-4"></div>
      </div>
    </section>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script
      src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
      integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
      integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
      integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
