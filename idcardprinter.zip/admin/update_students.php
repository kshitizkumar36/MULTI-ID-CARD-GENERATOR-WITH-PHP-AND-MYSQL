
<?php  include'header.php'; ?>

<?php
include'class.php';
$class_var= new details;
$entry_by="".$_SESSION['login']."";

$mydata= $class_var->get_products($entry_by);

?>

      
 <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">
              <h2>Welcome <?php echo $entry_by; ?></h2>
            <h5>Manage Students</h5>
             <?php 
  
  if("". $_SESSION['failed'] ."")
  {
    $show= "". $_SESSION['failed'] ."";
    ?>

    <div class="alert alert-danger" role="alert">
      <?php echo $show;
      unset($_SESSION['failed']);
       ?>
    </div>
    <?php
  }
 ?>
       <?php 

  
  if("". $_SESSION['success'] ."")
  {
    $show= "". $_SESSION['success'] ."";
    ?>

    <div class="alert alert-success" role="alert">
      <?php echo $show;
      unset($_SESSION['success']);
       ?>
    </div>
    <?php
  }

 ?>

<div class="row">
  <div class="col-lg-12 mb-4 order-0">
    <div class="card">
      <div class="d-flex align-items-end row">
        <div class="col-sm-12">
        
          <div class="card-body">
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Add Students</button>

        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="p-3">
                <p>Please Fill the Details to Add Students</p>
                <form class="border border-primary p-2" method="post" action="backend.php" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-sm-4">
                      <label>ID No <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="272" name="ID_no">
                    </div>
                      <div class="col-sm-4">
                      <label>Session<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder=" 2023-25" name="session">
                    </div>
                      <div class="col-sm-4">
                      <label>Roll No<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="273" name="s_roll_no">
                    </div>
                    <div class="col-sm-12">
                      <label>Blood Group <span class="text-danger">*</span></label>
                     <input type="text" class="form-control" placeholder="O+" name="blood_group">
                    </div>
                    <div class="col-sm-4">
                      <label>Student Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Student Name" name="student_name">
                    </div>
                      <div class="col-sm-4">
                      <label>Program Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Program Name" name="program_name">
                    </div>
                      <div class="col-sm-4">
                      <label>Father Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Father Name" name="father_name">
                    </div>

                      <div class="col-sm-4">
                      <label>DOB<span class="text-danger">*</span></label>
                      <input type="date" class="form-control" placeholder="DOB" name="dob">
                    </div>


                      <div class="col-sm-4">
                      <label>Address<span class="text-danger">*</span></label>
                      <textarea class="form-control" placeholder="Address" name="address"></textarea>
                    </div>
                     <div class="col-sm-4">
                      <label>Mobile<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Mobile" name="mobile">
                    </div>


                     <div class="col-sm-4">
                      <label>Email<span class="text-danger">*</span></label>
                      <input type="email" class="form-control" placeholder="Email" name="email">
                    </div>


                     <div class="col-sm-4">
                      <label>Principle Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" value="B.P. Verma"  name="principle_name">
                    </div>

                     

                      <div class="col-sm-4">
                      <label>Student Photo<span class="text-danger">*</span></label>
                      <input type="file" class="form-control" name="student_photo">
                    </div>

                   </div>
                   <br>


                   <input type="hidden" value="<?php echo $entry_by; ?>" name="entry_by">
                  <div class="text-center">
                    <button type="submit" name="new_students" class="btn btn-success">Submit Details</button>
                  </div>

                </form>
              </div>
            </div>
          </div>
        </div>
        <hr>
            <h5>View Students</h5>
              <div class="table-responsive text-nowrap">
            <table class="table" id="myTable">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">ID NO</th>
              <th scope="col">Generate ID</th>
              <th scope="col">Session</th>
              <th scope="col">ROll No</th>
              <th scope="col">Blood Group</th>
              <th scope="col">Student Name</th>
              <th scope="col">Program Name</th>
              <th scope="col">Father Name</th>
              <th scope="col">DOB</th>
              <th scope="col">Address</th>
              <th scope="col">Mobile</th>
              <th scope="col">Email</th>
             <th scope="col">Principle Name</th>
             <th scope="col">Photo</th>
             <th scope="col">Entry By</th>
             <th scope="col">Update</th>
              <th scope="col">Action</th>

            </tr>
          </thead>
          <tbody>
            <?php
            $count=1;
            foreach ($mydata as $key)
             {
              ?>
                 <tr>
                  <td><?php echo $count++; ?></td>
                  <td><?php echo $key['id_no']; ?></td>
                  <td><a target="_blank" href="idcard.php?id=<?php echo $key['id']; ?>"><button class="btn btn-primary">View ID</button></a></td>
                   <td><?php echo $key['session']; ?></td>
                  <td><?php echo $key['roll_no']; ?></td>
                  <td><?php echo $key['blood_group']; ?></td>
                  <td><?php echo $key['student_name']; ?></td>
                  <td><?php echo $key['program_name']; ?></td>
                  <td><?php echo $key['father_name']; ?></td>
                  <td><?php echo $key['dob']; ?></td>
                  <td><?php echo $key['address']; ?></td>
                  <td><?php echo $key['mobile']; ?></td>
                  <td><?php echo $key['email']; ?></td>
                  <td><?php echo $key['principle_name']; ?></td>
                  <td><img width="50" src="../student_photo/<?php echo $key['student_photo']; ?>"></td>
                  
                  
                  <td><?php echo $key['entry_by']; ?></td>
                  <td>
                    <!-- update -->
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalupdate<?php echo $key['id']; ?>">
                      Update Student
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModalupdate<?php echo $key['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Update Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form method="post" action="backend.php">
                              <div class="row">
                                <div class="col-sm-4">
                                  <label>ID No <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" value="<?php echo $key['id_no']; ?>" name="ID_no">
                                </div>
                                  <div class="col-sm-4">
                                  <label>Session<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value=" <?php echo $key['session']; ?>" name="session">
                                </div>
                                  <div class="col-sm-4">
                                  <label>Roll No<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="<?php echo $key['roll_no']; ?>" name="s_roll_no">
                                </div>
                                <div class="col-sm-12">
                                  <label>Blood Group <span class="text-danger">*</span></label>
                                 <input type="text" class="form-control" value="<?php echo $key['blood_group']; ?>" name="blood_group">
                                </div>

                               
                                
                                
                                <div class="col-sm-4">
                                  <label>Student Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="<?php echo $key['student_name']; ?>" name="student_name">
                                </div>
                                  <div class="col-sm-4">
                                  <label>Program Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="<?php echo $key['program_name']; ?>" name="program_name">
                                </div>
                                  <div class="col-sm-4">
                                  <label>Father Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="<?php echo $key['father_name']; ?>" name="father_name">
                                </div>

                                  <div class="col-sm-4">
                                  <label>DOB<span class="text-danger">*</span></label>
                                  <input type="date" class="form-control" value="<?php echo $key['dob']; ?>" name="dob">
                                </div>


                                  <div class="col-sm-4">
                                  <label>Address<span class="text-danger">*</span></label>
                                  <textarea class="form-control" name="address"><?php echo $key['address']; ?></textarea>
                                </div>
                                 <div class="col-sm-4">
                                  <label>Mobile<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="<?php echo $key['mobile']; ?>" name="mobile">
                                </div>


                                 <div class="col-sm-4">
                                  <label>Email<span class="text-danger">*</span></label>
                                  <input type="email" class="form-control" value="<?php echo $key['email']; ?>" name="email">
                                </div>


                                 <div class="col-sm-4">
                                  <label>Principle Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" value="B.P. Verma"  name="principle_name">
                                </div>
                                <input type="hidden" value="<?php echo $key['id']; ?>" name="table_id">
                              </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="update_data" class="btn btn-primary">Save changes</button>
                          </div>
                            </form>

                        </div>
                      </div>
                    </div>

                    <!-- update// -->
                  </td>
                  <td>
                                <a href="backend.php?remove_product=<?php echo $key['id'];  ?>"><i class="bx bx-trash me-1"></i></a>
                              </td>
                </tr>

              <?php
            }

            ?>
         
        
          </tbody>
        </table>
      </div>


          </div>
        </div>
       
      </div>
    </div>
  </div>
 

<?php  include'footer.php'; ?>